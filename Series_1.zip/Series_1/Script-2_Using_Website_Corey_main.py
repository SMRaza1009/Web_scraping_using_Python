from bs4 import BeautifulSoup
import requests
import csv


source = requests.get('https://coreyms.com').text

soup = BeautifulSoup(source,'lxml')

# article = soup.find('article')

# #print(article.prettify())

# headline = article.h2.a.text
# print(headline)

# # To grab the text of video details
# summary = article.find('div', class_='entry-content').p.text
# print(summary)

# # Finding video link from the div

# video_link = article.find('iframe', class_='youtube-player')['src']
# #print()
# #print(video_link)

# # Fetching the ID from the link by using splitting technique...

# # Method 1

# # vid_id = video_link.split('/')

# # get_id = vid_id[4].split('?')
# # print(get_id[0])

# # Method 2

# vid_id_2 = video_link.split('/')[4]

# vid_id_2 = vid_id_2.split('?')[0]

# # print(vid_id_2)

# yt_link = f'https://www.youtube.com/watch?v={vid_id_2}'

# print(yt_link)

# Finding all the articles and applying all the above techniques

# We will save all the data in the csv file
csv_data = open('cms_scrape.csv', 'w')

csv_writer = csv.writer(csv_data)

csv_writer.writerow(['headline','summary','video_link'])

for article in soup.find_all('article'):

    headline = article.h2.a.text
    print(headline)

    # To grab the text of video details
    summary = article.find('div', class_='entry-content').p.text
    print(summary)

    ''' We are using here try and catch condition because, if there is any missing 
     information in the page, code with break to avoid this condiotion ''' 
    try:
        # Finding video link from the div
        video_link = article.find('iframe', class_='youtube-player')['src']

        # Fetching the ID from the link by using splitting technique...

        vid_id_2 = video_link.split('/')[4]

        vid_id_2 = vid_id_2.split('?')[0]

        yt_link = f'https://www.youtube.com/watch?v={vid_id_2}'
    
    
    except Exception as e:
        yt_link = None
    
    print(yt_link)
    
    print()
    
    csv_writer.writerow([headline,summary,yt_link])

csv_data.close()



