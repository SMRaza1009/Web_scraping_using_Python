from bs4 import BeautifulSoup
import requests


with open('simple_html_practice_1.htm') as html_file:
    soup = BeautifulSoup(html_file, 'lxml')
    
    
# print(soup.prettify()) # shows the html code with corrent indended form

# Fetch Title of html page 
# match = soup.title.text # text --> means it remove the title tags, it shows simple text. 
# print(match)

# Fetch the first div!!!!
# match = soup.div.text
# print(match)


# Fetch Footer
# match = soup.find('div', class_='footer').text
# print(match)

# article = soup.find('div', class_='article')
# print(arcticle)

# Finding specific tag parent and child relationship

# headline = article.h2.a.text
# print(headline)

# summary = article.p.text
# print(summary)


# Finding all the articles in one single page and print div class 'articles' 

for article in soup.find_all('div', class_='article'):
    headline = article.h2.a.text
    print(headline)
    
    summary = article.p.text
    print(summary)
    
    print()
    
    




