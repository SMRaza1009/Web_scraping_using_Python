import requests 
from bs4 import BeautifulSoup
import pandas as pd


url = "https://www.iplt20.com/auction/2022#:~:text=TATA%20IPL%20Auction%20%2D%202022,IPL)%202022%20Auction%20in%20Bengaluru."

re = requests.get(url)

soup = BeautifulSoup(re.text, "lxml")

# print(soup)

# Now getting table data only

table = soup.find("table",class_="ih-td-tab auction-tbl")
# print(table.prettify())

title = table.find_all("th")
# print(title)


header_list = []
for i in title:
    name = i.text
    header_list.append(name)
    

# print(header_list)    

# Now making data frame for adding the extarting items in DF

df = pd.DataFrame(columns=header_list)

# print(df)     

# Extracting Data from rows

rows = table.find_all("tr")

# print(rows)

for i in rows[1:]:
    
    # Removing extra spaces and unnecessary tags
    
    first_td = i.find_all("td")[0].find("div", class_="ih-pt-ic").text.strip()   # The strip method remove the white space 
    data = i.find_all("td")[1:]
    # print(data)
    # Using list comprehension for extracting each single row
    
    row = [tr.text for tr in data]
    # print(row)
    row.insert(0, first_td)
    length_df = len(df)
    df.loc[length_df] = row
    
print(df)            

df.to_csv("ipl auctions stats.csv")