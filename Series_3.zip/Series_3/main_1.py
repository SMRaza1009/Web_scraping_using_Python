import requests
from bs4 import BeautifulSoup
import re

url = "https://webscraper.io/test-sites/e-commerce/allinone/computers/tablets"

get_url = requests.get(url)

doc = BeautifulSoup(get_url.text, "lxml")
#print(doc)

# item_boxes = doc.find_all("div", class_="col-sm-4 col-lg-4 col-md-4")
# print(len(item_boxes))

item_name = doc.find_all("a",class_="title")
#print(item_name)

# for name in item_name:
#     print(name.text)
    
item_price = doc.find_all("h4", class_="pull-right price")

# for price in item_price:
#     print(price.text)   

# Next task is to get item name and price combine!  