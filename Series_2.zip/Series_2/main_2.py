from bs4 import BeautifulSoup
import re

with open("index2.html", 'r') as f:
    doc = BeautifulSoup(f, "html.parser")
    
tag = doc.find("option") # find method gives the first matches, while find_all gives all the options
#result = doc.find_all("option")

# Now we will modify the attributes of these tags 

# tag['value'] = "Type of course"
# tag['selected'] = "false"
# tag['color'] = "blue"
# print(tag)

# # See all attributes in this tag

# print(tag.attrs)

# Get all the tags using List

#tags = doc.find_all(["p", "div", "li"])

#tags = doc.find_all(["option"], text="Undergraduate", value="undergraduate")

# tags = doc.find_all(class_="btn-item")
# print(tags)

#tags = doc.find_all(text=re.compile("\$.*")) # for all the $ prices

# tags = doc.find_all(text=re.compile("\$.*"), limit=1) # for limited numbers

# for tag in tags:
#     print(tag.strip()) # strip method remove white spaces

# Modify and changes in the document

tags = doc.find_all("input", type="text")
for tag in tags:
    tag['placeholder'] ="I changed you!"
    
with open("changed.html", "w") as file:
    file.write(str(doc))    
    