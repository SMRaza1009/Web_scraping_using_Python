from bs4 import BeautifulSoup 
import requests

# BeautifulSoup

# with open("index.html",'r') as f:
#     doc = BeautifulSoup(f, "html.parser")
    
# #print(doc.prettify())

# tag = doc.title
# #print(tag.string)

# # Now we can also modify tag as well as
# tag = doc.title
# tag.string = " Once again hello!"

# #print(tag.string) 
# #print(doc.prettify())

# # Now we can find tags by name 

# #tag = doc.find_all("a")
# tag = doc.find_all("p")[0]
# print(doc.find_all("b"))

# Requests 

url = "https://www.newegg.ca/msi-geforce-rtx-3080-rtx-3080-ventus-3x-plus-12g-oc-lhr/p/N82E16814137712?Description=3080&cm_re=3080-_-14-137-712-_-Product"

result = requests.get(url) 
#print(result.text)

doc = BeautifulSoup(result.text, "html.parser")
prices = doc.find_all(text="$")
parent = prices[0].parent

strong = parent.find("strong")
print(strong.string)
#print(doc.prettify())