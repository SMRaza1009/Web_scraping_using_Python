from bs4 import BeautifulSoup
import requests
import re

search_data = input('Which GPU card price you want? ')

url = f"https://www.newegg.ca/p/pl?d={search_data}&N=4131"

page = requests.get(url).text

doc = BeautifulSoup(page, "html.parser")

page_text_find = doc.find(class_="list-tool-pagination").strong
get_page_num = int(str(page_text_find).split("/")[-2].split(">")[-1][:-1])
print(get_page_num)

items_found = {}

for page_searching in range (1, get_page_num + 1):
    url = f"https://www.newegg.ca/p/pl?d={search_data}&N=4131&page={page_searching}"
    page_searching = requests.get(url).text
    doc = BeautifulSoup(page_searching, "html.parser")
    
    div = doc.find(class_="item-cells-wrap border-cells items-grid-view four-cells expulsion-one-cell")
    items = div.find_all(text=re.compile(search_data))
    #print(items)
    
    for item in items:
        parent = item.parent
        if parent.name != "a":
            continue
        
        link = parent["href"]
        # Now finding the price
        next_parent = item.find_parent(class_="item-container")
        try:
            price = next_parent.find(class_="price-current").find("strong").string
            items_found[item] = {"price": int(price.replace(",", "")), "link": link}
        except:
            pass         
        #print(link)
        #print(price)    
#print(items_found)

sorted_items = sorted(items_found.items(), key=lambda x: x[1]['price'])

for item in sorted_items:
    print(item[0])
    print(f"${item[1]['price']}")
    print(item[1]['link'])
    print("-------------------------------")
#     for item in items:
#         parent = item.parent
#         #print(parent)
#         if parent.name!=("a"):
#             continue
#         link = parent["href"]
#         #print(link)
        
#         next_parent = item.find_parent(class_="item-container")
#         #print(next_parent)
#         try:
#             price = next_parent.find(class_="price-current").find("strong").string()
#             items_found[item]={"price": int(price.replace(",","")), "link":link}
#         except:
#             pass
#         print(link)
#         print(price)
# sorted_price = sorted(items_found.items(), key=lambda x : x[1]['price'])        

# for items in sorted_price:
#     print(item[0])
#     print(f"${item[1]['price']}")
#     print(item[1]['link'])
#     print("-------------------------------")    
