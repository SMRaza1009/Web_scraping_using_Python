from bs4 import BeautifulSoup
import requests

url = "https://coinmarketcap.com/"
results = requests.get(url).text

doc = BeautifulSoup(results, "html.parser")

tbody = doc.tbody
#print(tbody.prettify)

# Now getting the list of content in the tbody tag 
trs = tbody.contents
#print(trs)
#print(trs[0].parent.name)
#print(trs[0].next_sibling)

#print(trs[1].previous_sibling)

#print(list(trs[0].next_siblings))

#print(list(trs[0].descendants))
#print(list(trs[0].contents))
#print(list(trs[0].children))

# Now we get the name of the coins with respect to their price

# prices = {}

# for tr in trs[:10]:
#     #for td in tr.contents[2:4]:
#     name, price = tr.contents[2:4]
#     #print(name.p.string)
#     fix_name = name.p.string
#     fix_price = price.a.string
#     #print(fix_name + " "+ fix_price)
#     prices[fix_name] =fix_price
    
# print(prices)


 

    