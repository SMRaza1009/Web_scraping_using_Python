from bs4 import BeautifulSoup 
import requests
import re

url = "https://coinmarketcap.com/"

fetch_data = requests.get(url).text  

doc = BeautifulSoup(fetch_data, "html.parser")

table_data = doc.tbody
#print(table_data.prettify)

tr_body = table_data.contents

# print(tr_body)

data = {}

try:
    for tr in tr_body[:10]:
        name, price= tr.contents[2:4]
        fix_name = name.p.string
        price = price.a.string
        data[fix_name] = price
    #print(data)
except:
    pass  

ne_dict = {}

for item in tr_body[10:]:
    # for items in item.contents[2:4]:
    #     #new_item = item.contents[2:4]
    #     test = items.text
    #     print(test)
    #     #print(items.text)
    name, price= item.contents[2:4]
    fix_name = name.text
    price = price.text
    data[fix_name] = price
print(data)
    # print(fix_name)
    # print(price)